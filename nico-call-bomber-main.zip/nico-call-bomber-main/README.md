## REVENGEBOMBER2.0 🔴🔴🔴🔴🔴🔴🔴🔴🔴

<h1 align="center">
  <br>
  <a href="https://github.com/AlexBieber/RevengeBomber"><img src="https://horoshop.ua/content/images/16/kak-sdelat-chtoby-pisma-ne-popadali-v-spam-11248663734326.jpg" alt="RevengeBomber"></a>
  <br>
  RevengeBomber2.0🔴🔴🔴🔴
  <br>
</h1>
<p align="center">
  <img src="https://img.shields.io/badge/Version-1.0-green?style=for-the-badge">
  <img src="https://img.shields.io/github/license/alexbieber/RevengeBomber2.0?style=for-the-badge">
  <img src="https://img.shields.io/github/stars/alexbieber/RevengeBomber2.0?style=for-the-badge">
  <img src="https://img.shields.io/github/issues/alexbieber/RevengeBomber2.0?color=red&style=for-the-badge">
  <img src="https://img.shields.io/github/forks/alexbieber/RevengeBomber2.0?color=teal&style=for-the-badge">
</p>


##

<h3 align="center">
:: Workflow ::
</h3>
<p align="center">
<img src="https://images.prismic.io/pepipost/e3269b46-fa9c-4a6f-945a-eccc268cd2dd_types+of+emails+scam.gif?auto=compress,format"/>
</p>
 <a href="https://www.buymeacoffee.com/alexbieber" target="_blank"><img src="https://www.buymeacoffee.com/assets/img/custom_images/orange_img.png" alt="Buy Me A Coffee" style="height: 41px !important;width: 174px !important;box-shadow: 0px 3px 2px 0px rgba(190, 190, 190, 0.5) !important;-webkit-box-shadow: 0px 3px 2px 0px rgba(190, 190, 190, 0.5) !important;" ></a>

## About Tool:

- The script requires working network connection to work.
- No balance will be deducted for using this script to send SMS/calls.
- While doing infinite bombing use 2-3 seconds delay and 10 to 20 threads for maximum performance.
- Don't put spaces in between phone number (Ex- 99999 99999)
- Make sure you are using the latest version of RevengeBomber2.0
- Make sure you are using Python3.

## Features:

- sms bombing
- call bombing
- mail bombing
- whatsapp bombing
- Frequent updates

## Available On
- Termux
- Kali Linux
- macOS

## VIDEO TUTORIAL FOR KALI LINUX USERS----

[![IMAGE ALT TEXT HERE](https://img.youtube.com/vi/qDqeSkAV4aw/0.jpg)](https://www.youtube.com/watch?v=qDqeSkAV4aw)

## Test On:
- Termux
- Mi Note 9 pro

## INSTALLATION [Termux] :

* `apt update`
* `apt upgrade`
* `pkg install python`
* `pkg install python2`
* `pkg install git`
* `git clone https://github.com/AlexBieber/RevengeBomber2.0`
* `ls`
* `cd RevengeBomber2.0`
* `pip2 install -r requirements.txt`
* `chmod +x RevengeBomber2.0.sh`
* `./RevengeBomber.sh Or bash RevengeBomber2.0.sh`

## INSTALLATION [Kali Linux] :

* `sudo apt install python`
* `sudo apt install python2`
* `sudo apt install git`
* `git clone https://github.com/AlexBieber/RevengeBomber2.0`
* `ls`
* `Now in root permission do`
* `cd RevengeBomber2.0`
* `pip install -r requirements.txt`
* `chmod +x RevengeBomber2.0.sh`

* `now open a new terminal again and without giving root permission` 
* `cd RevengeBomber2.0`
* `./RevengeBomber.sh Or bash RevengeBomber2.0.sh`

## INSTALLATION macOS:

* `brew install git`
* `brew install python3`
* `sudo easy_install pip`
* `sudo pip install --upgrade pip`
* `git clone https://github.com/AlexBieber/RevengeBomber2.0`
* `cd RevengeBomber2.0`
* `chmod +x RevengeBomber2.0.sh`
* `bash RevengeBomber2.0.sh`

## Screenshot:
<br>
<p align="center">
<img width="90%" 
src="https://github.com/AlexBieber/RevengeBomber2.0/blob/main/master/RevengeBomber2.0.jpg"\>

## Warning:
#### This tool is only for educational purpose. If you use this tool for other purposes except education we will not be responsible in such cases
  
  
## YOU CAN BUY ME A COFFEE-->  <a href="https://www.buymeacoffee.com/alexbieber" target="_blank"><img src="https://www.buymeacoffee.com/assets/img/custom_images/orange_img.png" alt="Buy Me A Coffee" style="height: 41px !important;width: 174px !important;box-shadow: 0px 3px 2px 0px rgba(190, 190, 190, 0.5) !important;-webkit-box-shadow: 0px 3px 2px 0px rgba(190, 190, 190, 0.5) !important;" ></a>

## LOVE YOU 3000!🔴

  
  ### Find Me on :
<p align="left">
  <a href="https://github.com/alexbieber" target="_blank"><img src="https://img.shields.io/badge/Github-Alex--Bieber-green?style=for-the-badge&logo=github"></a>
  <a href="https://www.instagram.com/alexbieber1234" target="_blank"><img src="https://img.shields.io/badge/IG-%40alexbieber1234-red?style=for-the-badge&logo=instagram"></a>
</p>


## DONATE YOUR MONEY FOR HELPLESS PEOPLE AROUND THE WORLD! LETS HELP THEM TOGETHER- LOVE YOU 3000❤❤❤❤
<p>
  <a href="https://www.paypal.me/alexbieber1234">
      <img src="https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif" alt="paypal">
  </a>
</p>
# Donate your money and it will inspire soo many people to live their life.


 ## THANKS!  
   Enjoy ✔
 ## 
    🔴🔴🔴🔴  🔴   🔴  🔴 🔴    🔴 🔴   🔴    🔴     🔴  🔴🔴🔴      🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴
        🔴      🔴🔴🔴  🔴  🔴    🔴  🔴  🔴    🔴  🔴    🔴__\         🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴
        🔴      🔴   🔴 🔴🔴 🔴   🔴   🔴 🔴    🔴🔴 🔴       🔴        🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴
        🔴      🔴   🔴🔴     🔴   🔴    🔴🔴    🔴     🔴 🔴🔴🔴        🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴🔴


# THANKS FOR USING! LOVE YOU 3000!🔴🔴🔴🔴✔

